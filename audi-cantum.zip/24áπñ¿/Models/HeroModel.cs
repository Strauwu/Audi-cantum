﻿
namespace new_ga_e.Models
{
    public static class HeroModel
    {
        public static int idleFrame = 12;
        public static int healFrame = 12;
        public static int upFrame = 12;
        public static int downFrame = 12;
        public static int leftFrame = 12;
        public static int rightFrame = 12;

    }
}
