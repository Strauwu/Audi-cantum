﻿using new_ga_e.AudioGame;
using new_ga_e.Controlles;
using new_ga_e.Entities;

using new_ga_e.Models;
using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace new_ga_e
{
    public partial class Form1 : Form
    {
        public Image playerSheet;
        public PlayerEntity player;
        public Audio audi;
        bool repeat = true;

        public Form1()
        {
            InitializeComponent();

            timer1.Interval = 20;
            timer1.Tick += new EventHandler(Update);

            KeyDown += new KeyEventHandler(OnPress);
            KeyUp += new KeyEventHandler(OnKeyUp);

            Init();
        }

        public void Init()
        {
            MapController.Init();
            Width = MapController.GetWidth();
            Height = MapController.GetHeight();
            playerSheet = new Bitmap(Path.Combine(new DirectoryInfo(Directory.GetCurrentDirectory()).Parent.Parent.FullName.ToString(), "sprites\\gero.png"));
            player = new PlayerEntity(120, 110, HeroModel.idleFrame, HeroModel.healFrame, HeroModel.upFrame, HeroModel.downFrame, HeroModel.leftFrame, HeroModel.rightFrame, playerSheet);
            audi = new Audio(10);
            timer1.Start();
        }

        private void OnPaint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            MapController.DrawMap(g);
            player.PlayAnimation(g);
        }

        public void Update(object sender, EventArgs e)
        {
            if (!PhysicsController.IsCollide(player, new Point(player.dirX, player.dirY)))
            {
                if (player.IsMoving)
                    player.Move();
            }
            Invalidate();
        }

      

        public void OnPress(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.W:
                    player.dirY = -2;
                    player.IsMoving = true;
                    player.SetAnimationConfiguration(2);
                    break;
                case Keys.S:
                    player.dirY = 2;
                    player.IsMoving = true;
                    player.SetAnimationConfiguration(3);
                    break;
                case Keys.A:
                    player.dirX = -2;
                    player.IsMoving = true;
                    player.SetAnimationConfiguration(4);
                    break;
                case Keys.D:
                    player.dirX = 2;
                    player.IsMoving = true;
                    player.SetAnimationConfiguration(5);
                    break;
                case Keys.F:
                    
                    player.IsMoving = false;
                    player.IsHealing = true;
                    player.SetAnimationConfiguration(1);
                    break;
            }

        }
        public void OnKeyUp(object sender, KeyEventArgs e)
        {

            switch (e.KeyCode)
            {
                case Keys.W:
                    player.dirY = 0;
                    break;
                case Keys.S:
                    player.dirY = 0;
                    break;
                case Keys.A:
                    player.dirX = 0;
                    break;
                case Keys.D:
                    player.dirX = 0;
                    break;
                case Keys.F:
                    player.dirY = 0;
                    player.dirX = 0;
                    player.IsHealing = false;
                    break;
            }
            if (player.dirX == 0 && player.dirY == 0)
            {
                player.IsMoving = false;
                if (player.IsHealing==false)
                {
                    player.SetAnimationConfiguration(0);
                }
                player.SetAnimationConfiguration(0);
                  
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode == Keys.F) && repeat == true && player.IsHealing)
            {
                audi.Recording();
                repeat = false;
            }
            else if (!player.IsHealing)
            {
                repeat = true;
            }
        }
    }
}
